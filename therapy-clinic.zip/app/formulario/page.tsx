"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Checkbox } from "@/components/ui/checkbox"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { ArrowLeft, FileText, AlertCircle, CheckCircle } from "lucide-react"

export default function FormularioPage() {
  const [formData, setFormData] = useState({
    nomeCompleto: "",
    cpf: "",
    dataNascimento: "",
    idade: "",
    nomeCuidador: "",
    telefone: "",
    email: "",
    areaAtendimento: "",
    outroAreaAtendimento: "",
    diagnostico: "",
    outroDiagnostico: "",
    dificuldades: "",
    tempoDemanda: "",
    outroTempoDemanda: "",
    fazTerapiaOutroLocal: "",
    comoConheceu: "",
    outroComoConheceu: "",
    instituicaoEncaminhamento: "",
    preferenciaTurno: [] as string[],
    tipoAtendimentoPandemia: "",
    comentarios: "",
    concordaTermos: false,
  })

  const [isSubmitted, setIsSubmitted] = useState(false)

  const handleInputChange = (field: string, value: string | boolean | string[]) => {
    setFormData((prev) => ({
      ...prev,
      [field]: value,
    }))
  }

  const handleTurnoChange = (turno: string, checked: boolean) => {
    setFormData((prev) => ({
      ...prev,
      preferenciaTurno: checked ? [...prev.preferenciaTurno, turno] : prev.preferenciaTurno.filter((t) => t !== turno),
    }))
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!formData.concordaTermos) {
      alert("É necessário concordar com os termos para prosseguir.")
      return
    }
    // Aqui seria a integração com o backend
    console.log("Dados do formulário:", formData)
    setIsSubmitted(true)
  }

  if (isSubmitted) {
    return (
      <div className="min-h-screen bg-gray-50 py-12">
        <div className="container max-w-2xl mx-auto px-4">
          <Card className="border-green-200">
            <CardContent className="p-8 text-center">
              <div className="w-16 h-16 rounded-full bg-green-100 flex items-center justify-center mx-auto mb-4">
                <CheckCircle className="w-8 h-8 text-green-600" />
              </div>
              <h2 className="text-2xl font-bold text-green-900 mb-4">Formulário Enviado com Sucesso!</h2>
              <p className="text-gray-600 mb-6">
                Seu cadastro foi realizado e você foi incluído(a) na lista de espera da CETO/UFPR. Entraremos em contato
                via WhatsApp quando houver disponibilidade de vagas.
              </p>
              <div className="space-y-3">
                <Button asChild className="w-full bg-blue-600 hover:bg-blue-700">
                  <Link href="/">Voltar ao Site</Link>
                </Button>
                <Button variant="outline" className="w-full">
                  Falar no WhatsApp
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b shadow-sm">
        <div className="container flex h-16 items-center justify-between py-4">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="sm" asChild>
              <Link href="/">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Voltar
              </Link>
            </Button>
            <div className="flex items-center gap-2">
              <img
                src="/placeholder.svg?height=40&width=40"
                width={40}
                height={40}
                alt="Logo UFPR"
                className="rounded"
              />
              <div>
                <h1 className="font-bold text-blue-900">CETO/UFPR</h1>
                <p className="text-xs text-gray-600">Formulário de Inscrição</p>
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="py-8">
        <div className="container max-w-4xl mx-auto px-4">
          <div className="mb-8 text-center">
            <Badge variant="outline" className="text-blue-600 border-blue-600 mb-4">
              Inscrição CETO/UFPR
            </Badge>
            <h1 className="text-3xl font-bold text-blue-900 mb-2">Formulário de Cadastro</h1>
            <p className="text-gray-600">
              Preencha todos os campos obrigatórios (*) para se inscrever na lista de espera da CETO/UFPR
            </p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-8">
            {/* Dados Pessoais */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-blue-900">
                  <FileText className="w-5 h-5" />
                  Dados Pessoais
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid gap-4 md:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="nomeCompleto">Nome Completo *</Label>
                    <input
                      id="nomeCompleto"
                      type="text"
                      required
                      className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                      placeholder="Nome da pessoa que precisa do atendimento"
                      value={formData.nomeCompleto}
                      onChange={(e) => handleInputChange("nomeCompleto", e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="cpf">CPF *</Label>
                    <input
                      id="cpf"
                      type="text"
                      required
                      className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                      placeholder="000.000.000-00"
                      value={formData.cpf}
                      onChange={(e) => handleInputChange("cpf", e.target.value)}
                    />
                  </div>
                </div>

                <div className="grid gap-4 md:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="dataNascimento">Data de Nascimento</Label>
                    <input
                      id="dataNascimento"
                      type="date"
                      className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                      value={formData.dataNascimento}
                      onChange={(e) => handleInputChange("dataNascimento", e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="idade">Idade</Label>
                    <input
                      id="idade"
                      type="number"
                      className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                      placeholder="Idade em anos"
                      value={formData.idade}
                      onChange={(e) => handleInputChange("idade", e.target.value)}
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="nomeCuidador">Nome do(s) cuidador(es) ou responsável(is) (se preciso)</Label>
                  <input
                    id="nomeCuidador"
                    type="text"
                    className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                    placeholder="Nome do responsável ou cuidador"
                    value={formData.nomeCuidador}
                    onChange={(e) => handleInputChange("nomeCuidador", e.target.value)}
                  />
                </div>

                <div className="grid gap-4 md:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="telefone">Telefone Celular (com DDD)</Label>
                    <input
                      id="telefone"
                      type="tel"
                      className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                      placeholder="(00) 00000-0000"
                      value={formData.telefone}
                      onChange={(e) => handleInputChange("telefone", e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="email">E-mail</Label>
                    <input
                      id="email"
                      type="email"
                      className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                      placeholder="seu.email@exemplo.com"
                      value={formData.email}
                      onChange={(e) => handleInputChange("email", e.target.value)}
                    />
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Informações Clínicas */}
            <Card>
              <CardHeader>
                <CardTitle className="text-blue-900">Informações Clínicas</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-3">
                  <Label className="text-base font-medium">Área de atendimento desejada:</Label>
                  <RadioGroup
                    value={formData.areaAtendimento}
                    onValueChange={(value) => handleInputChange("areaAtendimento", value)}
                  >
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="neurologia-adulto" id="neurologia-adulto" />
                      <Label htmlFor="neurologia-adulto">Neurologia adulto</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="neurologia-infantil" id="neurologia-infantil" />
                      <Label htmlFor="neurologia-infantil">Neurologia infantil</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="saude-mental" id="saude-mental" />
                      <Label htmlFor="saude-mental">Saúde Mental</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="desenvolvimento-infantil-tea" id="desenvolvimento-infantil-tea" />
                      <Label htmlFor="desenvolvimento-infantil-tea">Desenvolvimento Infantil TEA</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="outro" id="area-outro" />
                      <Label htmlFor="area-outro">Outro:</Label>
                    </div>
                  </RadioGroup>
                  {formData.areaAtendimento === "outro" && (
                    <input
                      type="text"
                      className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                      placeholder="Especifique a área de atendimento"
                      value={formData.outroAreaAtendimento}
                      onChange={(e) => handleInputChange("outroAreaAtendimento", e.target.value)}
                    />
                  )}
                </div>

                <div className="space-y-3">
                  <Label className="text-base font-medium">
                    Diagnóstico da pessoa que necessita de atendimento (se houver):
                  </Label>
                  <RadioGroup
                    value={formData.diagnostico}
                    onValueChange={(value) => handleInputChange("diagnostico", value)}
                  >
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="avc" id="avc" />
                      <Label htmlFor="avc">Acidente Vascular Cerebral (AVC)</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="paralisia-cerebral" id="paralisia-cerebral" />
                      <Label htmlFor="paralisia-cerebral">Paralisia Cerebral (PC)</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="tea" id="tea" />
                      <Label htmlFor="tea">Transtorno do Espectro Autista (TEA)</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="nao-possui" id="nao-possui" />
                      <Label htmlFor="nao-possui">Não possui/ não sei</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="outro" id="diagnostico-outro" />
                      <Label htmlFor="diagnostico-outro">Outro:</Label>
                    </div>
                  </RadioGroup>
                  {formData.diagnostico === "outro" && (
                    <input
                      type="text"
                      className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                      placeholder="Especifique o diagnóstico"
                      value={formData.outroDiagnostico}
                      onChange={(e) => handleInputChange("outroDiagnostico", e.target.value)}
                    />
                  )}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="dificuldades">Dificuldades apresentadas (descrever brevemente):</Label>
                  <Textarea
                    id="dificuldades"
                    placeholder="Descreva brevemente as principais dificuldades apresentadas"
                    value={formData.dificuldades}
                    onChange={(e) => handleInputChange("dificuldades", e.target.value)}
                  />
                </div>

                <div className="space-y-3">
                  <Label className="text-base font-medium">Há quanto tempo apresenta a demanda?</Label>
                  <p className="text-sm text-gray-600">Tempo de diagnóstico ou lesão, por exemplo.</p>
                  <RadioGroup
                    value={formData.tempoDemanda}
                    onValueChange={(value) => handleInputChange("tempoDemanda", value)}
                  >
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="1-3-meses" id="1-3-meses" />
                      <Label htmlFor="1-3-meses">1 a 3 meses</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="3-6-meses" id="3-6-meses" />
                      <Label htmlFor="3-6-meses">3 a 6 meses</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="6-meses-1-ano" id="6-meses-1-ano" />
                      <Label htmlFor="6-meses-1-ano">6 meses a 1 ano</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="ate-3-anos" id="ate-3-anos" />
                      <Label htmlFor="ate-3-anos">Até 3 anos</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="mais-3-anos" id="mais-3-anos" />
                      <Label htmlFor="mais-3-anos">Mais de 3 anos</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="desde-nascimento" id="desde-nascimento" />
                      <Label htmlFor="desde-nascimento">Desde o nascimento</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="nao-aplicavel" id="nao-aplicavel" />
                      <Label htmlFor="nao-aplicavel">Não aplicável (não apresenta lesões)</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="outro" id="tempo-outro" />
                      <Label htmlFor="tempo-outro">Outro:</Label>
                    </div>
                  </RadioGroup>
                  {formData.tempoDemanda === "outro" && (
                    <input
                      type="text"
                      className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                      placeholder="Especifique o tempo"
                      value={formData.outroTempoDemanda}
                      onChange={(e) => handleInputChange("outroTempoDemanda", e.target.value)}
                    />
                  )}
                </div>

                <div className="space-y-3">
                  <Label className="text-base font-medium">
                    Realiza atendimento de Terapia Ocupacional em outro serviço atualmente?
                  </Label>
                  <RadioGroup
                    value={formData.fazTerapiaOutroLocal}
                    onValueChange={(value) => handleInputChange("fazTerapiaOutroLocal", value)}
                  >
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="sim" id="terapia-sim" />
                      <Label htmlFor="terapia-sim">Sim</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="nao" id="terapia-nao" />
                      <Label htmlFor="terapia-nao">Não</Label>
                    </div>
                  </RadioGroup>
                </div>
              </CardContent>
            </Card>

            {/* Informações Adicionais */}
            <Card>
              <CardHeader>
                <CardTitle className="text-blue-900">Informações Adicionais</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-3">
                  <Label className="text-base font-medium">Como conheceu a CETO?</Label>
                  <RadioGroup
                    value={formData.comoConheceu}
                    onValueChange={(value) => handleInputChange("comoConheceu", value)}
                  >
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="internet" id="internet" />
                      <Label htmlFor="internet">Pesquisei na internet</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="recomendacao-paciente" id="recomendacao-paciente" />
                      <Label htmlFor="recomendacao-paciente">
                        Recomendação de uma pessoa que já foi ou é atendida pela CETO
                      </Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="indicacao-profissional" id="indicacao-profissional" />
                      <Label htmlFor="indicacao-profissional">Indicação de um profissional de saúde</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="indicacao-unidade-saude" id="indicacao-unidade-saude" />
                      <Label htmlFor="indicacao-unidade-saude">Indicação da Unidade de Saúde</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="indicacao-hospital" id="indicacao-hospital" />
                      <Label htmlFor="indicacao-hospital">Indicação do hospital em que fui atendido</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="outro" id="conheceu-outro" />
                      <Label htmlFor="conheceu-outro">Outro:</Label>
                    </div>
                  </RadioGroup>
                  {formData.comoConheceu === "outro" && (
                    <input
                      type="text"
                      className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                      placeholder="Especifique como conheceu"
                      value={formData.outroComoConheceu}
                      onChange={(e) => handleInputChange("outroComoConheceu", e.target.value)}
                    />
                  )}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="instituicaoEncaminhamento">
                    Caso foi encaminhado por alguma instituição ou profissional favor descrever qual o local
                  </Label>
                  <input
                    id="instituicaoEncaminhamento"
                    type="text"
                    className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                    placeholder="Nome da instituição ou profissional"
                    value={formData.instituicaoEncaminhamento}
                    onChange={(e) => handleInputChange("instituicaoEncaminhamento", e.target.value)}
                  />
                </div>

                <div className="space-y-3">
                  <Label className="text-base font-medium">Preferência de turno para atendimento:</Label>
                  <p className="text-sm text-gray-600">É possível selecionar mais de uma opção.</p>
                  <div className="space-y-2">
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="manha"
                        checked={formData.preferenciaTurno.includes("manha")}
                        onCheckedChange={(checked) => handleTurnoChange("manha", checked as boolean)}
                      />
                      <Label htmlFor="manha">Manhã</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="tarde"
                        checked={formData.preferenciaTurno.includes("tarde")}
                        onCheckedChange={(checked) => handleTurnoChange("tarde", checked as boolean)}
                      />
                      <Label htmlFor="tarde">Tarde</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="noite"
                        checked={formData.preferenciaTurno.includes("noite")}
                        onCheckedChange={(checked) => handleTurnoChange("noite", checked as boolean)}
                      />
                      <Label htmlFor="noite">Noite</Label>
                    </div>
                  </div>
                </div>

                <div className="space-y-3">
                  <Label className="text-base font-medium">
                    No caso de abertura de vagas no período da pandemia, tem preferência por qual tipo de atendimento?
                  </Label>
                  <RadioGroup
                    value={formData.tipoAtendimentoPandemia}
                    onValueChange={(value) => handleInputChange("tipoAtendimentoPandemia", value)}
                  >
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="presencial" id="presencial" />
                      <Label htmlFor="presencial">Atendimento presencial (ir até a clínica para ser atendido)</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="remoto" id="remoto" />
                      <Label htmlFor="remoto">Atendimento remoto (atendimento por ligações de vídeo)</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="ambos" id="ambos" />
                      <Label htmlFor="ambos">
                        Atendimento presencial e/ou remoto (de acordo com a indicação da terapeuta)
                      </Label>
                    </div>
                  </RadioGroup>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="comentarios">Comentários adicionais (se houver):</Label>
                  <p className="text-sm text-gray-600">
                    Este espaço pode ser utilizado para informar a atualização de algum dado pessoal, registrar dúvidas
                    e sugestões.
                  </p>
                  <Textarea
                    id="comentarios"
                    placeholder="Comentários, dúvidas ou sugestões"
                    value={formData.comentarios}
                    onChange={(e) => handleInputChange("comentarios", e.target.value)}
                  />
                </div>
              </CardContent>
            </Card>

            {/* Termos */}
            <Card className="border-orange-200 bg-orange-50">
              <CardContent className="p-6">
                <div className="flex items-start space-x-3">
                  <AlertCircle className="w-5 h-5 text-orange-600 mt-0.5 flex-shrink-0" />
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <h3 className="font-semibold text-orange-900">Termo de Consentimento</h3>
                      <p className="text-sm text-orange-800">
                        Estou ciente que este é um cadastro em fila de espera para avaliação, e que não garante uma vaga
                        para atendimento. A disponibilidade de vagas depende dos projetos ofertados e da ordem de
                        cadastro, sendo um serviço aberto à comunidade, sem distinção de vínculo com a UFPR ou com
                        servidor. A data do primeiro cadastro será respeitada, sendo esta apenas uma atualização dos
                        meus dados.
                      </p>
                    </div>
                    <div className="space-y-3">
                      <RadioGroup
                        value={formData.concordaTermos ? "ciente" : ""}
                        onValueChange={(value) => handleInputChange("concordaTermos", value === "ciente")}
                      >
                        <div className="flex items-center space-x-2">
                          <RadioGroupItem value="ciente" id="ciente" />
                          <Label htmlFor="ciente">Ciente e de acordo</Label>
                        </div>
                        <div className="flex items-center space-x-2">
                          <RadioGroupItem value="nao-concordo" id="nao-concordo" />
                          <Label htmlFor="nao-concordo">Não concordo (neste caso o seu cadastro é invalidado)</Label>
                        </div>
                      </RadioGroup>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Botão de Envio */}
            <div className="flex justify-center pt-6">
              <Button
                type="submit"
                size="lg"
                className="bg-blue-600 hover:bg-blue-700 px-8"
                disabled={!formData.concordaTermos}
              >
                Enviar Formulário
              </Button>
            </div>
          </form>
        </div>
      </div>
    </div>
  )
}
