"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  Users,
  FileText,
  ClipboardList,
  Search,
  MoreHorizontal,
  Download,
  Filter,
  LogOut,
  Bell,
  User,
  Calendar,
  Clock,
  ChevronDown,
} from "lucide-react"
import { Badge } from "@/components/ui/badge"

// Tipos para os dados do paciente
interface Patient {
  id: string
  nomeCompleto: string
  cpf: string
  dataNascimento: string
  idade: string
  telefone: string
  email: string
  areaAtendimento: string
  diagnostico: string
  tempoDemanda: string
  fazTerapiaOutroLocal: string
  dataInscricao: string
  status: "espera" | "triagem" | "avaliacao" | "atendimento" | "alta"
}

// Dados de exemplo para demonstração
const mockPatients: Patient[] = [
  {
    id: "20251001",
    nomeCompleto: "Maria Silva Oliveira",
    cpf: "123.456.789-00",
    dataNascimento: "1985-06-15",
    idade: "38",
    telefone: "(41) 99999-8888",
    email: "maria.silva@email.com",
    areaAtendimento: "neurologia-adulto",
    diagnostico: "avc",
    tempoDemanda: "3-6-meses",
    fazTerapiaOutroLocal: "nao",
    dataInscricao: "2025-05-10",
    status: "espera",
  },
  {
    id: "20251002",
    nomeCompleto: "João Pedro Santos",
    cpf: "987.654.321-00",
    dataNascimento: "2018-03-22",
    idade: "7",
    telefone: "(41) 98765-4321",
    email: "ana.santos@email.com",
    areaAtendimento: "desenvolvimento-infantil-tea",
    diagnostico: "tea",
    tempoDemanda: "desde-nascimento",
    fazTerapiaOutroLocal: "sim",
    dataInscricao: "2025-05-12",
    status: "triagem",
  },
  {
    id: "20251003",
    nomeCompleto: "Carlos Eduardo Ferreira",
    cpf: "456.789.123-00",
    dataNascimento: "1972-11-30",
    idade: "52",
    telefone: "(41) 97777-6666",
    email: "carlos.ferreira@email.com",
    areaAtendimento: "neurologia-adulto",
    diagnostico: "avc",
    tempoDemanda: "1-3-meses",
    fazTerapiaOutroLocal: "nao",
    dataInscricao: "2025-05-15",
    status: "avaliacao",
  },
  {
    id: "20251004",
    nomeCompleto: "Ana Beatriz Mendes",
    cpf: "321.654.987-00",
    dataNascimento: "2015-08-10",
    idade: "9",
    telefone: "(41) 96666-5555",
    email: "patricia.mendes@email.com",
    areaAtendimento: "desenvolvimento-infantil-tea",
    diagnostico: "tea",
    tempoDemanda: "ate-3-anos",
    fazTerapiaOutroLocal: "nao",
    dataInscricao: "2025-05-18",
    status: "atendimento",
  },
  {
    id: "20251005",
    nomeCompleto: "Roberto Alves Costa",
    cpf: "789.123.456-00",
    dataNascimento: "1968-04-25",
    idade: "57",
    telefone: "(41) 95555-4444",
    email: "roberto.costa@email.com",
    areaAtendimento: "neurologia-adulto",
    diagnostico: "outro",
    tempoDemanda: "mais-3-anos",
    fazTerapiaOutroLocal: "nao",
    dataInscricao: "2025-05-20",
    status: "alta",
  },
]

// Função para traduzir os valores do banco de dados para texto legível
const translateValue = (key: string, value: string): string => {
  const translations: Record<string, Record<string, string>> = {
    areaAtendimento: {
      "neurologia-adulto": "Neurologia Adulto",
      "neurologia-infantil": "Neurologia Infantil",
      "saude-mental": "Saúde Mental",
      "desenvolvimento-infantil-tea": "Desenvolvimento Infantil TEA",
    },
    diagnostico: {
      avc: "AVC",
      "paralisia-cerebral": "Paralisia Cerebral",
      tea: "TEA",
      "nao-possui": "Não possui/não sabe",
    },
    tempoDemanda: {
      "1-3-meses": "1 a 3 meses",
      "3-6-meses": "3 a 6 meses",
      "6-meses-1-ano": "6 meses a 1 ano",
      "ate-3-anos": "Até 3 anos",
      "mais-3-anos": "Mais de 3 anos",
      "desde-nascimento": "Desde o nascimento",
      "nao-aplicavel": "Não aplicável",
    },
    fazTerapiaOutroLocal: {
      sim: "Sim",
      nao: "Não",
    },
    status: {
      espera: "Lista de Espera",
      triagem: "Triagem",
      avaliacao: "Avaliação",
      atendimento: "Em Atendimento",
      alta: "Alta",
    },
  }

  return translations[key]?.[value] || value
}

// Componente para o status badge
const StatusBadge = ({ status }: { status: Patient["status"] }) => {
  const statusStyles: Record<Patient["status"], { color: string; bg: string }> = {
    espera: { color: "text-amber-700", bg: "bg-amber-100" },
    triagem: { color: "text-blue-700", bg: "bg-blue-100" },
    avaliacao: { color: "text-purple-700", bg: "bg-purple-100" },
    atendimento: { color: "text-green-700", bg: "bg-green-100" },
    alta: { color: "text-gray-700", bg: "bg-gray-100" },
  }

  const style = statusStyles[status]

  return <Badge className={`${style.bg} ${style.color} hover:${style.bg}`}>{translateValue("status", status)}</Badge>
}

export default function AdminDashboard() {
  const router = useRouter()
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [searchTerm, setSearchTerm] = useState("")
  const [statusFilter, setStatusFilter] = useState<string>("all")
  const [areaFilter, setAreaFilter] = useState<string>("all")
  const [currentTab, setCurrentTab] = useState("pacientes")

  // Verificar autenticação ao carregar a página
  useEffect(() => {
    const auth = localStorage.getItem("cetoAuth")
    if (auth !== "true") {
      router.push("/admin/login")
    } else {
      setIsAuthenticated(true)
    }
  }, [router])

  // Filtrar pacientes com base nos critérios de busca e filtros
  const filteredPatients = mockPatients.filter((patient) => {
    // Filtro de busca
    const matchesSearch =
      searchTerm === "" ||
      patient.nomeCompleto.toLowerCase().includes(searchTerm.toLowerCase()) ||
      patient.cpf.includes(searchTerm) ||
      patient.id.includes(searchTerm)

    // Filtro de status
    const matchesStatus = statusFilter === "all" || patient.status === statusFilter

    // Filtro de área
    const matchesArea = areaFilter === "all" || patient.areaAtendimento === areaFilter

    return matchesSearch && matchesStatus && matchesArea
  })

  // Função para fazer logout
  const handleLogout = () => {
    localStorage.removeItem("cetoAuth")
    router.push("/admin/login")
  }

  // Função para exportar dados (simulada)
  const handleExport = () => {
    alert("Exportação de dados iniciada. O arquivo será baixado em breve.")
  }

  if (!isAuthenticated) {
    return null // Não renderiza nada enquanto verifica autenticação
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="sticky top-0 z-40 w-full border-b bg-white shadow-sm">
        <div className="container flex h-16 items-center justify-between">
          <div className="flex items-center gap-4">
            <Link href="/" className="flex items-center gap-2">
              <img
                src="/placeholder.svg?height=40&width=40"
                width={40}
                height={40}
                alt="Logo UFPR"
                className="rounded"
              />
              <div>
                <h1 className="font-bold text-blue-900">CETO/UFPR</h1>
                <p className="text-xs text-gray-600">Painel Administrativo</p>
              </div>
            </Link>
          </div>

          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon">
              <Bell className="h-5 w-5" />
            </Button>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="flex items-center gap-2">
                  <User className="h-5 w-5" />
                  <span className="hidden md:inline">Administrador</span>
                  <ChevronDown className="h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem>Perfil</DropdownMenuItem>
                <DropdownMenuItem>Configurações</DropdownMenuItem>
                <DropdownMenuItem onClick={handleLogout}>
                  <LogOut className="h-4 w-4 mr-2" />
                  Sair
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </header>

      <div className="container py-6">
        <div className="mb-6">
          <h1 className="text-2xl font-bold text-gray-900">Painel Administrativo</h1>
          <p className="text-gray-600">Gerencie pacientes, agendamentos e relatórios da CETO/UFPR</p>
        </div>

        {/* Cards de resumo */}
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4 mb-6">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-gray-500">Total de Pacientes</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between">
                <div className="text-2xl font-bold">{mockPatients.length}</div>
                <Users className="h-5 w-5 text-blue-600" />
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-gray-500">Lista de Espera</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between">
                <div className="text-2xl font-bold">{mockPatients.filter((p) => p.status === "espera").length}</div>
                <ClipboardList className="h-5 w-5 text-amber-600" />
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-gray-500">Em Atendimento</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between">
                <div className="text-2xl font-bold">
                  {mockPatients.filter((p) => p.status === "atendimento").length}
                </div>
                <Calendar className="h-5 w-5 text-green-600" />
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-gray-500">Agendamentos Hoje</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between">
                <div className="text-2xl font-bold">3</div>
                <Clock className="h-5 w-5 text-purple-600" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Tabs */}
        <Tabs value={currentTab} onValueChange={setCurrentTab} className="w-full">
          <TabsList className="mb-4">
            <TabsTrigger value="pacientes" className="flex items-center gap-2">
              <Users className="h-4 w-4" />
              Pacientes
            </TabsTrigger>
            <TabsTrigger value="agendamentos" className="flex items-center gap-2">
              <Calendar className="h-4 w-4" />
              Agendamentos
            </TabsTrigger>
            <TabsTrigger value="relatorios" className="flex items-center gap-2">
              <FileText className="h-4 w-4" />
              Relatórios
            </TabsTrigger>
          </TabsList>

          <TabsContent value="pacientes" className="space-y-4">
            <div className="flex flex-col md:flex-row gap-4 justify-between">
              <div className="relative w-full md:w-1/3">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
                <Input
                  placeholder="Buscar por nome, CPF ou prontuário..."
                  className="pl-9"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
              <div className="flex flex-col md:flex-row gap-2">
                <div className="flex items-center gap-2">
                  <Select value={statusFilter} onValueChange={setStatusFilter}>
                    <SelectTrigger className="w-full md:w-[180px]">
                      <div className="flex items-center gap-2">
                        <Filter className="h-4 w-4" />
                        <SelectValue placeholder="Status" />
                      </div>
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Todos os status</SelectItem>
                      <SelectItem value="espera">Lista de Espera</SelectItem>
                      <SelectItem value="triagem">Triagem</SelectItem>
                      <SelectItem value="avaliacao">Avaliação</SelectItem>
                      <SelectItem value="atendimento">Em Atendimento</SelectItem>
                      <SelectItem value="alta">Alta</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="flex items-center gap-2">
                  <Select value={areaFilter} onValueChange={setAreaFilter}>
                    <SelectTrigger className="w-full md:w-[180px]">
                      <div className="flex items-center gap-2">
                        <Filter className="h-4 w-4" />
                        <SelectValue placeholder="Área" />
                      </div>
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Todas as áreas</SelectItem>
                      <SelectItem value="neurologia-adulto">Neurologia Adulto</SelectItem>
                      <SelectItem value="neurologia-infantil">Neurologia Infantil</SelectItem>
                      <SelectItem value="saude-mental">Saúde Mental</SelectItem>
                      <SelectItem value="desenvolvimento-infantil-tea">Desenvolvimento Infantil TEA</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <Button variant="outline" onClick={handleExport}>
                  <Download className="h-4 w-4 mr-2" />
                  Exportar
                </Button>
              </div>
            </div>

            <Card>
              <CardContent className="p-0">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Prontuário</TableHead>
                      <TableHead>Nome</TableHead>
                      <TableHead className="hidden md:table-cell">Área</TableHead>
                      <TableHead className="hidden md:table-cell">Data Inscrição</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead className="w-[50px]"></TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredPatients.length > 0 ? (
                      filteredPatients.map((patient) => (
                        <TableRow key={patient.id}>
                          <TableCell className="font-medium">{patient.id}</TableCell>
                          <TableCell>
                            <div>
                              <div>{patient.nomeCompleto}</div>
                              <div className="text-xs text-gray-500 md:hidden">
                                {translateValue("areaAtendimento", patient.areaAtendimento)}
                              </div>
                            </div>
                          </TableCell>
                          <TableCell className="hidden md:table-cell">
                            {translateValue("areaAtendimento", patient.areaAtendimento)}
                          </TableCell>
                          <TableCell className="hidden md:table-cell">{patient.dataInscricao}</TableCell>
                          <TableCell>
                            <StatusBadge status={patient.status} />
                          </TableCell>
                          <TableCell>
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button variant="ghost" size="icon">
                                  <MoreHorizontal className="h-4 w-4" />
                                </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="end">
                                <DropdownMenuItem asChild>
                                  <Link href={`/admin/pacientes/${patient.id}`}>Ver detalhes</Link>
                                </DropdownMenuItem>
                                <DropdownMenuItem>Editar</DropdownMenuItem>
                                <DropdownMenuItem>Alterar status</DropdownMenuItem>
                                <DropdownMenuItem>Agendar</DropdownMenuItem>
                              </DropdownMenuContent>
                            </DropdownMenu>
                          </TableCell>
                        </TableRow>
                      ))
                    ) : (
                      <TableRow>
                        <TableCell colSpan={6} className="text-center py-6 text-gray-500">
                          Nenhum paciente encontrado com os critérios de busca.
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="agendamentos">
            <Card>
              <CardHeader>
                <CardTitle>Agendamentos</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-500">
                  Esta seção está em desenvolvimento. Aqui serão exibidos os agendamentos de consultas e avaliações.
                </p>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="relatorios">
            <Card>
              <CardHeader>
                <CardTitle>Relatórios</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-500">
                  Esta seção está em desenvolvimento. Aqui serão exibidos relatórios e estatísticas da clínica.
                </p>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
