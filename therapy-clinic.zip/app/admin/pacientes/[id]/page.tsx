"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { ArrowLeft, Calendar, Clock, Download, Edit, FileText, MessageCircle, Phone, User } from "lucide-react"

// Tipos para os dados do paciente
interface Patient {
  id: string
  nomeCompleto: string
  cpf: string
  dataNascimento: string
  idade: string
  nomeCuidador?: string
  telefone: string
  email: string
  areaAtendimento: string
  outroAreaAtendimento?: string
  diagnostico: string
  outroDiagnostico?: string
  dificuldades: string
  tempoDemanda: string
  outroTempoDemanda?: string
  fazTerapiaOutroLocal: string
  comoConheceu: string
  outroComoConheceu?: string
  instituicaoEncaminhamento?: string
  preferenciaTurno: string[]
  tipoAtendimentoPandemia: string
  comentarios?: string
  dataInscricao: string
  status: "espera" | "triagem" | "avaliacao" | "atendimento" | "alta"
}

// Dados de exemplo para demonstração
const mockPatient: Patient = {
  id: "20251001",
  nomeCompleto: "Maria Silva Oliveira",
  cpf: "123.456.789-00",
  dataNascimento: "1985-06-15",
  idade: "38",
  nomeCuidador: "",
  telefone: "(41) 99999-8888",
  email: "maria.silva@email.com",
  areaAtendimento: "neurologia-adulto",
  diagnostico: "avc",
  dificuldades:
    "Dificuldade de movimentação do lado direito do corpo, especialmente braço e mão. Apresenta dificuldades na fala e na realização de atividades diárias como vestir-se e alimentar-se.",
  tempoDemanda: "3-6-meses",
  fazTerapiaOutroLocal: "nao",
  comoConheceu: "indicacao-hospital",
  instituicaoEncaminhamento: "Hospital de Clínicas - UFPR",
  preferenciaTurno: ["manha", "tarde"],
  tipoAtendimentoPandemia: "presencial",
  comentarios: "Paciente muito motivada para o tratamento. Mora com o marido que pode acompanhá-la nas sessões.",
  dataInscricao: "2025-05-10",
  status: "espera",
}

// Função para traduzir os valores do banco de dados para texto legível
const translateValue = (key: string, value: string): string => {
  const translations: Record<string, Record<string, string>> = {
    areaAtendimento: {
      "neurologia-adulto": "Neurologia Adulto",
      "neurologia-infantil": "Neurologia Infantil",
      "saude-mental": "Saúde Mental",
      "desenvolvimento-infantil-tea": "Desenvolvimento Infantil TEA",
    },
    diagnostico: {
      avc: "AVC",
      "paralisia-cerebral": "Paralisia Cerebral",
      tea: "TEA",
      "nao-possui": "Não possui/não sabe",
    },
    tempoDemanda: {
      "1-3-meses": "1 a 3 meses",
      "3-6-meses": "3 a 6 meses",
      "6-meses-1-ano": "6 meses a 1 ano",
      "ate-3-anos": "Até 3 anos",
      "mais-3-anos": "Mais de 3 anos",
      "desde-nascimento": "Desde o nascimento",
      "nao-aplicavel": "Não aplicável",
    },
    fazTerapiaOutroLocal: {
      sim: "Sim",
      nao: "Não",
    },
    comoConheceu: {
      internet: "Pesquisei na internet",
      "recomendacao-paciente": "Recomendação de uma pessoa que já foi ou é atendida pela CETO",
      "indicacao-profissional": "Indicação de um profissional de saúde",
      "indicacao-unidade-saude": "Indicação da Unidade de Saúde",
      "indicacao-hospital": "Indicação do hospital em que foi atendido",
    },
    tipoAtendimentoPandemia: {
      presencial: "Atendimento presencial",
      remoto: "Atendimento remoto",
      ambos: "Atendimento presencial e/ou remoto",
    },
    status: {
      espera: "Lista de Espera",
      triagem: "Triagem",
      avaliacao: "Avaliação",
      atendimento: "Em Atendimento",
      alta: "Alta",
    },
  }

  return translations[key]?.[value] || value
}

// Componente para o status badge
const StatusBadge = ({ status }: { status: Patient["status"] }) => {
  const statusStyles: Record<Patient["status"], { color: string; bg: string }> = {
    espera: { color: "text-amber-700", bg: "bg-amber-100" },
    triagem: { color: "text-blue-700", bg: "bg-blue-100" },
    avaliacao: { color: "text-purple-700", bg: "bg-purple-100" },
    atendimento: { color: "text-green-700", bg: "bg-green-100" },
    alta: { color: "text-gray-700", bg: "bg-gray-100" },
  }

  const style = statusStyles[status]

  return <Badge className={`${style.bg} ${style.color} hover:${style.bg}`}>{translateValue("status", status)}</Badge>
}

// Componente para exibir um campo de informação
const InfoField = ({ label, value }: { label: string; value: string | string[] | undefined }) => {
  if (!value || (Array.isArray(value) && value.length === 0)) return null

  return (
    <div className="mb-4">
      <p className="text-sm font-medium text-gray-500">{label}</p>
      <p className="mt-1">
        {Array.isArray(value) ? value.map((v) => translateValue("preferenciaTurno", v)).join(", ") : value}
      </p>
    </div>
  )
}

export default function PatientDetails({ params }: { params: { id: string } }) {
  const router = useRouter()
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [patient, setPatient] = useState<Patient | null>(null)

  // Verificar autenticação ao carregar a página
  useEffect(() => {
    const auth = localStorage.getItem("cetoAuth")
    if (auth !== "true") {
      router.push("/admin/login")
    } else {
      setIsAuthenticated(true)
      // Em um ambiente real, aqui você buscaria os dados do paciente da API
      // usando o ID da URL (params.id)
      setPatient(mockPatient)
    }
  }, [router, params.id])

  if (!isAuthenticated || !patient) {
    return null // Não renderiza nada enquanto verifica autenticação ou carrega dados
  }

  // Formatar a data de nascimento
  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return date.toLocaleDateString("pt-BR")
  }

  // Calcular idade a partir da data de nascimento
  const calculateAge = (birthDateString: string) => {
    const birthDate = new Date(birthDateString)
    const today = new Date()
    let age = today.getFullYear() - birthDate.getFullYear()
    const monthDiff = today.getMonth() - birthDate.getMonth()

    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
      age--
    }

    return age
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="sticky top-0 z-40 w-full border-b bg-white shadow-sm">
        <div className="container flex h-16 items-center justify-between">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="sm" asChild>
              <Link href="/admin/dashboard">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Voltar
              </Link>
            </Button>
            <div>
              <h1 className="font-bold text-blue-900">Detalhes do Paciente</h1>
              <p className="text-xs text-gray-600">Prontuário {patient.id}</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm">
              <Edit className="h-4 w-4 mr-2" />
              Editar
            </Button>
            <Button variant="outline" size="sm">
              <Download className="h-4 w-4 mr-2" />
              Exportar
            </Button>
            <Button size="sm" className="bg-blue-600 hover:bg-blue-700">
              <Calendar className="h-4 w-4 mr-2" />
              Agendar
            </Button>
          </div>
        </div>
      </header>

      <div className="container py-6">
        <div className="grid gap-6 md:grid-cols-3">
          {/* Coluna da esquerda - Informações do paciente */}
          <div className="space-y-6">
            <Card>
              <CardHeader className="pb-2">
                <div className="flex justify-between items-center">
                  <CardTitle className="text-lg">Informações do Paciente</CardTitle>
                  <StatusBadge status={patient.status} />
                </div>
              </CardHeader>
              <CardContent>
                <div className="flex items-center gap-4 mb-4 pb-4 border-b">
                  <div className="w-16 h-16 rounded-full bg-blue-100 flex items-center justify-center">
                    <User className="h-8 w-8 text-blue-600" />
                  </div>
                  <div>
                    <h2 className="font-bold text-lg">{patient.nomeCompleto}</h2>
                    <p className="text-sm text-gray-500">
                      {calculateAge(patient.dataNascimento)} anos • Prontuário {patient.id}
                    </p>
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <p className="text-sm font-medium text-gray-500">CPF</p>
                      <p className="mt-1">{patient.cpf}</p>
                    </div>
                    <div>
                      <p className="text-sm font-medium text-gray-500">Data de Nascimento</p>
                      <p className="mt-1">{formatDate(patient.dataNascimento)}</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 py-2">
                    <Phone className="h-4 w-4 text-blue-600" />
                    <a href={`tel:${patient.telefone}`} className="text-blue-600 hover:underline">
                      {patient.telefone}
                    </a>
                  </div>

                  <div className="flex items-center gap-2 py-2">
                    <MessageCircle className="h-4 w-4 text-green-600" />
                    <a
                      href={`https://wa.me/${patient.telefone.replace(/\D/g, "")}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-green-600 hover:underline"
                    >
                      Enviar WhatsApp
                    </a>
                  </div>

                  <InfoField label="E-mail" value={patient.email} />
                  <InfoField label="Cuidador/Responsável" value={patient.nomeCuidador} />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-lg">Dados da Inscrição</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <p className="text-sm font-medium text-gray-500">Data de Inscrição</p>
                  <p className="mt-1">{formatDate(patient.dataInscricao)}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-gray-500">Como conheceu a CETO</p>
                  <p className="mt-1">{translateValue("comoConheceu", patient.comoConheceu)}</p>
                </div>
                <InfoField label="Instituição de Encaminhamento" value={patient.instituicaoEncaminhamento} />
                <div>
                  <p className="text-sm font-medium text-gray-500">Preferência de Turno</p>
                  <p className="mt-1">
                    {patient.preferenciaTurno
                      .map((turno) => {
                        switch (turno) {
                          case "manha":
                            return "Manhã"
                          case "tarde":
                            return "Tarde"
                          case "noite":
                            return "Noite"
                          default:
                            return turno
                        }
                      })
                      .join(", ")}
                  </p>
                </div>
                <div>
                  <p className="text-sm font-medium text-gray-500">Tipo de Atendimento</p>
                  <p className="mt-1">{translateValue("tipoAtendimentoPandemia", patient.tipoAtendimentoPandemia)}</p>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Coluna da direita - Informações clínicas e abas */}
          <div className="md:col-span-2 space-y-6">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-lg">Informações Clínicas</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm font-medium text-gray-500">Área de Atendimento</p>
                    <p className="mt-1">{translateValue("areaAtendimento", patient.areaAtendimento)}</p>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-500">Diagnóstico</p>
                    <p className="mt-1">{translateValue("diagnostico", patient.diagnostico)}</p>
                  </div>
                </div>

                <div>
                  <p className="text-sm font-medium text-gray-500">Tempo da Demanda</p>
                  <p className="mt-1">{translateValue("tempoDemanda", patient.tempoDemanda)}</p>
                </div>

                <div>
                  <p className="text-sm font-medium text-gray-500">Realiza TO em outro local</p>
                  <p className="mt-1">{translateValue("fazTerapiaOutroLocal", patient.fazTerapiaOutroLocal)}</p>
                </div>

                <div>
                  <p className="text-sm font-medium text-gray-500">Dificuldades Apresentadas</p>
                  <p className="mt-1 text-gray-700">{patient.dificuldades}</p>
                </div>

                <InfoField label="Comentários Adicionais" value={patient.comentarios} />
              </CardContent>
            </Card>

            <Tabs defaultValue="prontuario" className="w-full">
              <TabsList className="mb-4">
                <TabsTrigger value="prontuario" className="flex items-center gap-2">
                  <FileText className="h-4 w-4" />
                  Prontuário
                </TabsTrigger>
                <TabsTrigger value="agendamentos" className="flex items-center gap-2">
                  <Calendar className="h-4 w-4" />
                  Agendamentos
                </TabsTrigger>
                <TabsTrigger value="evolucao" className="flex items-center gap-2">
                  <Clock className="h-4 w-4" />
                  Evolução
                </TabsTrigger>
              </TabsList>

              <TabsContent value="prontuario">
                <Card>
                  <CardContent className="p-6">
                    <div className="text-center py-8">
                      <FileText className="h-12 w-12 mx-auto text-gray-400 mb-4" />
                      <h3 className="text-lg font-medium mb-2">Prontuário Eletrônico</h3>
                      <p className="text-gray-500 mb-4">
                        O prontuário eletrônico será disponibilizado após a avaliação inicial do paciente.
                      </p>
                      <Button variant="outline">Criar Prontuário</Button>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="agendamentos">
                <Card>
                  <CardContent className="p-6">
                    <div className="text-center py-8">
                      <Calendar className="h-12 w-12 mx-auto text-gray-400 mb-4" />
                      <h3 className="text-lg font-medium mb-2">Sem Agendamentos</h3>
                      <p className="text-gray-500 mb-4">Este paciente ainda não possui agendamentos registrados.</p>
                      <Button className="bg-blue-600 hover:bg-blue-700">
                        <Calendar className="h-4 w-4 mr-2" />
                        Agendar Consulta
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="evolucao">
                <Card>
                  <CardContent className="p-6">
                    <div className="text-center py-8">
                      <Clock className="h-12 w-12 mx-auto text-gray-400 mb-4" />
                      <h3 className="text-lg font-medium mb-2">Evolução do Tratamento</h3>
                      <p className="text-gray-500 mb-4">
                        Os registros de evolução serão exibidos aqui após o início do tratamento.
                      </p>
                      <Button variant="outline">Registrar Evolução</Button>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </div>
    </div>
  )
}
