import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import {
  Clock,
  MapPin,
  Users,
  BookOpen,
  Heart,
  ArrowRight,
  MessageCircle,
  FileText,
  UserCheck,
  ClipboardList,
  FolderOpen,
} from "lucide-react"

export default function Home() {
  return (
    <div className="flex flex-col min-h-screen">
      <header className="sticky top-0 z-40 w-full border-b bg-white shadow-sm">
        <div className="container flex h-20 items-center justify-between py-4">
          <div className="flex items-center gap-4">
            <img
              src="/placeholder.svg?height=60&width=60"
              width={60}
              height={60}
              alt="Logo UFPR"
              className="rounded-lg"
            />
            <div>
              <h1 className="text-lg font-bold text-blue-900">CETO/UFPR</h1>
              <p className="text-sm text-gray-600">Clínica-Escola de Terapia Ocupacional</p>
            </div>
          </div>
          <nav className="hidden md:flex items-center gap-6 text-sm">
            <Link href="#sobre" className="font-medium transition-colors hover:text-blue-600">
              Sobre
            </Link>
            <Link href="#servicos" className="font-medium transition-colors hover:text-blue-600">
              Serviços
            </Link>
            <Link href="#fluxo" className="font-medium transition-colors hover:text-blue-600">
              Como Funciona
            </Link>
            <Link href="#inscricao" className="font-medium transition-colors hover:text-blue-600">
              Inscrição
            </Link>
            <Link href="#contato" className="font-medium transition-colors hover:text-blue-600">
              Contato
            </Link>
          </nav>
          <Button className="bg-blue-600 hover:bg-blue-700">
            <MessageCircle className="w-4 h-4 mr-2" />
            WhatsApp
          </Button>
        </div>
      </header>

      <main className="flex-1">
        {/* Hero Section */}
        <section className="w-full py-12 md:py-24 lg:py-32 bg-gradient-to-r from-blue-50 to-indigo-50">
          <div className="container px-4 md:px-6">
            <div className="grid gap-6 lg:grid-cols-2 lg:gap-12 items-center">
              <div className="space-y-6">
                <div className="space-y-2">
                  <Badge variant="outline" className="text-blue-600 border-blue-600">
                    Universidade Federal do Paraná
                  </Badge>
                  <h1 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl lg:text-6xl/none text-blue-900">
                    Clínica-Escola de Terapia Ocupacional
                  </h1>
                  <p className="max-w-[600px] text-gray-600 md:text-xl">
                    Integrando ensino, pesquisa e extensão para oferecer atendimento especializado em terapia
                    ocupacional à comunidade.
                  </p>
                </div>
                <div className="flex flex-col gap-2 min-[400px]:flex-row">
                  <Button size="lg" className="bg-blue-600 hover:bg-blue-700" asChild>
                    <Link href="/formulario">
                      <FileText className="w-4 h-4 mr-2" />
                      Fazer Inscrição
                    </Link>
                  </Button>
                  <Button variant="outline" size="lg">
                    <MessageCircle className="w-4 h-4 mr-2" />
                    Falar no WhatsApp
                  </Button>
                </div>
                <div className="flex items-center gap-6 text-sm text-gray-600">
                  <div className="flex items-center gap-2">
                    <Users className="w-4 h-4" />
                    <span>Atendimento supervisionado</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <BookOpen className="w-4 h-4" />
                    <span>Formação acadêmica</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Heart className="w-4 h-4" />
                    <span>Cuidado integral</span>
                  </div>
                </div>
              </div>
              <img
                src="/placeholder.svg?height=500&width=600"
                width={600}
                height={500}
                alt="Estudantes e professores da CETO/UFPR em atendimento"
                className="mx-auto aspect-video overflow-hidden rounded-xl object-cover object-center sm:w-full"
              />
            </div>
          </div>
        </section>

        {/* Sobre Section */}
        <section id="sobre" className="w-full py-12 md:py-24 lg:py-32">
          <div className="container px-4 md:px-6">
            <div className="grid gap-6 lg:grid-cols-2 lg:gap-12 items-center">
              <img
                src="/placeholder.svg?height=400&width=600"
                width={600}
                height={400}
                alt="Campus Jardim Botânico UFPR"
                className="mx-auto aspect-video overflow-hidden rounded-xl object-cover object-center sm:w-full"
              />
              <div className="space-y-4">
                <div className="space-y-2">
                  <Badge variant="outline" className="text-blue-600 border-blue-600">
                    Sobre a CETO
                  </Badge>
                  <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl text-blue-900">
                    Formação e Cuidado
                  </h2>
                </div>
                <div className="space-y-4 text-gray-600">
                  <p className="md:text-lg">
                    A Clínica-Escola de Terapia Ocupacional da UFPR é uma unidade acadêmica vinculada ao Departamento de
                    Terapia Ocupacional, fundamentada na integração entre ensino, pesquisa e extensão.
                  </p>
                  <p>
                    Nosso propósito principal é proporcionar experiências práticas aos acadêmicos, articulando
                    conhecimentos teóricos às demandas sociais e de saúde da população. Todo atendimento é
                    supervisionado por docentes e profissionais qualificados.
                  </p>
                  <p>
                    Localizada estrategicamente no Campus Jardim Botânico da UFPR, em Curitiba, oferecemos fácil acesso
                    tanto para a comunidade interna quanto para a população em geral.
                  </p>
                </div>
                <div className="flex items-center gap-2 text-blue-600">
                  <MapPin className="w-4 h-4" />
                  <span className="font-medium">Campus Jardim Botânico - Curitiba/PR</span>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Serviços Section */}
        <section id="servicos" className="w-full py-12 md:py-24 lg:py-32 bg-gray-50">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <Badge variant="outline" className="text-blue-600 border-blue-600">
                  Nossos Serviços
                </Badge>
                <h2 className="text-3xl font-bold tracking-tighter sm:text-5xl text-blue-900">Áreas de Atendimento</h2>
                <p className="max-w-[900px] text-gray-600 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                  Oferecemos atendimento especializado em duas principais áreas de atuação da terapia ocupacional.
                </p>
              </div>
            </div>
            <div className="mx-auto grid max-w-5xl grid-cols-1 gap-8 py-12 md:grid-cols-2">
              <Card className="relative overflow-hidden border-2 hover:border-blue-200 transition-colors">
                <CardHeader className="pb-4">
                  <div className="w-12 h-12 rounded-lg bg-blue-100 flex items-center justify-center mb-4">
                    <Heart className="w-6 h-6 text-blue-600" />
                  </div>
                  <CardTitle className="text-xl text-blue-900">Reabilitação Neurológica</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-gray-600">
                    Atendimento especializado para adultos com condições neurológicas, focando na recuperação funcional
                    e independência.
                  </p>
                  <div className="space-y-2">
                    <h4 className="font-semibold text-blue-900">Principais condições atendidas:</h4>
                    <ul className="space-y-1 text-sm text-gray-600">
                      <li>• Acidente Vascular Cerebral (AVC)</li>
                      <li>• Lesões encefálicas</li>
                      <li>• Outras condições neurológicas</li>
                      <li>• Reabilitação física e funcional</li>
                    </ul>
                  </div>
                </CardContent>
              </Card>

              <Card className="relative overflow-hidden border-2 hover:border-blue-200 transition-colors">
                <CardHeader className="pb-4">
                  <div className="w-12 h-12 rounded-lg bg-blue-100 flex items-center justify-center mb-4">
                    <Users className="w-6 h-6 text-blue-600" />
                  </div>
                  <CardTitle className="text-xl text-blue-900">Desenvolvimento Infantil</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-gray-600">
                    Acompanhamento especializado no desenvolvimento infantil, com ênfase no atendimento a crianças com
                    necessidades especiais.
                  </p>
                  <div className="space-y-2">
                    <h4 className="font-semibold text-blue-900">Principais focos:</h4>
                    <ul className="space-y-1 text-sm text-gray-600">
                      <li>• Transtorno do Espectro Autista (TEA)</li>
                      <li>• Atrasos no desenvolvimento</li>
                      <li>• Dificuldades de integração sensorial</li>
                      <li>• Habilidades motoras e cognitivas</li>
                    </ul>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* Fluxo de Atendimento */}
        <section id="fluxo" className="w-full py-12 md:py-24 lg:py-32">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center mb-12">
              <Badge variant="outline" className="text-blue-600 border-blue-600">
                Como Funciona
              </Badge>
              <h2 className="text-3xl font-bold tracking-tighter sm:text-5xl text-blue-900">Fluxo de Atendimento</h2>
              <p className="max-w-[900px] text-gray-600 md:text-xl/relaxed">
                Conheça o processo desde a inscrição até o início do atendimento na CETO/UFPR.
              </p>
            </div>

            <div className="max-w-4xl mx-auto">
              <div className="space-y-8">
                {/* Etapa 1 */}
                <div className="flex gap-4 items-start">
                  <div className="flex-shrink-0 w-12 h-12 rounded-full bg-blue-600 text-white flex items-center justify-center font-bold">
                    1
                  </div>
                  <div className="flex-1">
                    <Card>
                      <CardHeader>
                        <CardTitle className="flex items-center gap-2 text-blue-900">
                          <FileText className="w-5 h-5" />
                          Inscrição via Formulário
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <p className="text-gray-600 mb-4">
                          Preencha nosso formulário online ou solicite ajuda via WhatsApp para o preenchimento.
                        </p>
                        <Button className="bg-blue-600 hover:bg-blue-700">Acessar Formulário</Button>
                      </CardContent>
                    </Card>
                  </div>
                </div>

                {/* Etapa 2 */}
                <div className="flex gap-4 items-start">
                  <div className="flex-shrink-0 w-12 h-12 rounded-full bg-blue-600 text-white flex items-center justify-center font-bold">
                    2
                  </div>
                  <div className="flex-1">
                    <Card>
                      <CardHeader>
                        <CardTitle className="flex items-center gap-2 text-blue-900">
                          <ClipboardList className="w-5 h-5" />
                          Lista de Espera
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <p className="text-gray-600">
                          Após a inscrição, você entrará na lista de espera da especialidade correspondente. Alinhamos
                          horários desejados e realizamos o agendamento para avaliação conforme disponibilidade.
                        </p>
                      </CardContent>
                    </Card>
                  </div>
                </div>

                {/* Etapa 3 */}
                <div className="flex gap-4 items-start">
                  <div className="flex-shrink-0 w-12 h-12 rounded-full bg-blue-600 text-white flex items-center justify-center font-bold">
                    3
                  </div>
                  <div className="flex-1">
                    <Card>
                      <CardHeader>
                        <CardTitle className="flex items-center gap-2 text-blue-900">
                          <UserCheck className="w-5 h-5" />
                          Avaliação Inicial
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <p className="text-gray-600 mb-2">
                          Avaliação para determinar se o paciente será incluído no serviço.
                        </p>
                        <p className="text-sm text-gray-500">
                          <strong>Importante:</strong> Pacientes que já fazem terapia ocupacional em outro local não têm
                          prioridade.
                        </p>
                      </CardContent>
                    </Card>
                  </div>
                </div>

                {/* Etapa 4 */}
                <div className="flex gap-4 items-start">
                  <div className="flex-shrink-0 w-12 h-12 rounded-full bg-blue-600 text-white flex items-center justify-center font-bold">
                    4
                  </div>
                  <div className="flex-1">
                    <Card>
                      <CardHeader>
                        <CardTitle className="flex items-center gap-2 text-blue-900">
                          <FileText className="w-5 h-5" />
                          Contrato Terapêutico
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-2 text-gray-600">
                          <p>Se incluído no serviço, será estabelecido um contrato terapêutico com:</p>
                          <ul className="space-y-1 text-sm ml-4">
                            <li>• Critérios de frequência (máximo 3 faltas)</li>
                            <li>• Renovação a cada semestre</li>
                            <li>• Modelos específicos para neurologia e TEA</li>
                          </ul>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                </div>

                {/* Etapa 5 */}
                <div className="flex gap-4 items-start">
                  <div className="flex-shrink-0 w-12 h-12 rounded-full bg-blue-600 text-white flex items-center justify-center font-bold">
                    5
                  </div>
                  <div className="flex-1">
                    <Card>
                      <CardHeader>
                        <CardTitle className="flex items-center gap-2 text-blue-900">
                          <FolderOpen className="w-5 h-5" />
                          Prontuário e Atendimento
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-2 text-gray-600">
                          <p>Criação do prontuário com número único contendo:</p>
                          <ul className="space-y-1 text-sm ml-4">
                            <li>• Ficha de anamnese</li>
                            <li>• Avaliação inicial</li>
                            <li>• Plano de tratamento</li>
                            <li>• Ficha de frequência</li>
                            <li>• Evoluções das sessões</li>
                            <li>• Relatório final</li>
                          </ul>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Inscrição Section */}
        <section id="inscricao" className="w-full py-12 md:py-24 lg:py-32 bg-blue-50">
          <div className="container px-4 md:px-6">
            <div className="max-w-3xl mx-auto text-center space-y-8">
              <div className="space-y-4">
                <Badge variant="outline" className="text-blue-600 border-blue-600">
                  Inscrição
                </Badge>
                <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl text-blue-900">Como se Inscrever</h2>
                <p className="text-gray-600 md:text-lg">
                  Escolha a forma mais conveniente para iniciar seu processo de inscrição na CETO/UFPR.
                </p>
              </div>

              <div className="grid gap-6 md:grid-cols-2">
                <Card className="border-2 hover:border-blue-200 transition-colors">
                  <CardHeader className="text-center">
                    <div className="w-16 h-16 rounded-full bg-blue-100 flex items-center justify-center mx-auto mb-4">
                      <FileText className="w-8 h-8 text-blue-600" />
                    </div>
                    <CardTitle className="text-blue-900">Formulário Online</CardTitle>
                  </CardHeader>
                  <CardContent className="text-center space-y-4">
                    <p className="text-gray-600">Preencha diretamente nosso formulário de inscrição online.</p>
                    <Button className="w-full bg-blue-600 hover:bg-blue-700" asChild>
                      <Link href="/formulario">
                        Acessar Formulário
                        <ArrowRight className="w-4 h-4 ml-2" />
                      </Link>
                    </Button>
                  </CardContent>
                </Card>

                <Card className="border-2 hover:border-blue-200 transition-colors">
                  <CardHeader className="text-center">
                    <div className="w-16 h-16 rounded-full bg-green-100 flex items-center justify-center mx-auto mb-4">
                      <MessageCircle className="w-8 h-8 text-green-600" />
                    </div>
                    <CardTitle className="text-blue-900">WhatsApp</CardTitle>
                  </CardHeader>
                  <CardContent className="text-center space-y-4">
                    <p className="text-gray-600">Solicite ajuda para preenchimento ou tire dúvidas pelo WhatsApp.</p>
                    <Button className="w-full bg-green-600 hover:bg-green-700">
                      Falar no WhatsApp
                      <ArrowRight className="w-4 h-4 ml-2" />
                    </Button>
                  </CardContent>
                </Card>
              </div>

              <div className="bg-white rounded-lg p-6 border">
                <h3 className="font-semibold text-blue-900 mb-3">Informações Importantes:</h3>
                <ul className="space-y-2 text-sm text-gray-600 text-left">
                  <li>• As vagas são disponibilizadas conforme oferta dos estágios e projetos</li>
                  <li>• O acesso se dá por meio de lista de espera seguida de triagem</li>
                  <li>• A confirmação da consulta é feita via WhatsApp</li>
                  <li>• Todos os atendimentos são supervisionados por docentes qualificados</li>
                </ul>
              </div>
            </div>
          </div>
        </section>

        {/* Contato Section */}
        <section id="contato" className="w-full py-12 md:py-24 lg:py-32">
          <div className="container px-4 md:px-6">
            <div className="grid gap-6 lg:grid-cols-2 lg:gap-12 items-start">
              <div className="space-y-6">
                <div className="space-y-2">
                  <Badge variant="outline" className="text-blue-600 border-blue-600">
                    Contato
                  </Badge>
                  <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl text-blue-900">Entre em Contato</h2>
                  <p className="text-gray-600 md:text-lg">
                    Estamos aqui para esclarecer suas dúvidas e auxiliar no processo de inscrição.
                  </p>
                </div>

                <div className="space-y-4">
                  <Card>
                    <CardContent className="p-4">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-full bg-green-100 flex items-center justify-center">
                          <MessageCircle className="w-5 h-5 text-green-600" />
                        </div>
                        <div>
                          <p className="font-medium text-blue-900">WhatsApp</p>
                          <p className="text-sm text-gray-600">Primeiro contato e suporte</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardContent className="p-4">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center">
                          <MapPin className="w-5 h-5 text-blue-600" />
                        </div>
                        <div>
                          <p className="font-medium text-blue-900">Localização</p>
                          <p className="text-sm text-gray-600">Campus Jardim Botânico - UFPR</p>
                          <p className="text-sm text-gray-600">Curitiba, Paraná</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardContent className="p-4">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center">
                          <Clock className="w-5 h-5 text-blue-600" />
                        </div>
                        <div>
                          <p className="font-medium text-blue-900">Funcionamento</p>
                          <p className="text-sm text-gray-600">Conforme cronograma acadêmico</p>
                          <p className="text-sm text-gray-600">Atendimentos supervisionados</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </div>

              <Card>
                <CardHeader>
                  <CardTitle className="text-blue-900">Dúvidas Frequentes</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <h4 className="font-semibold text-blue-900">Como funciona a lista de espera?</h4>
                    <p className="text-sm text-gray-600">
                      Após a inscrição, você entra na lista de espera da especialidade correspondente. As vagas são
                      oferecidas conforme disponibilidade dos estágios.
                    </p>
                  </div>

                  <div className="space-y-2">
                    <h4 className="font-semibold text-blue-900">Qual o custo do atendimento?</h4>
                    <p className="text-sm text-gray-600">
                      Por ser uma clínica-escola da universidade pública, os atendimentos são gratuitos para a
                      comunidade.
                    </p>
                  </div>

                  <div className="space-y-2">
                    <h4 className="font-semibold text-blue-900">Quem realiza os atendimentos?</h4>
                    <p className="text-sm text-gray-600">
                      Os atendimentos são realizados por estudantes do curso de Terapia Ocupacional sob supervisão de
                      docentes e profissionais qualificados.
                    </p>
                  </div>

                  <div className="pt-4">
                    <Button className="w-full bg-green-600 hover:bg-green-700">
                      <MessageCircle className="w-4 h-4 mr-2" />
                      Falar no WhatsApp
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>
      </main>

      <footer className="w-full border-t bg-blue-900 text-white py-12">
        <div className="container px-4 md:px-6">
          <div className="grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-4">
            <div className="space-y-4">
              <div className="flex items-center gap-2">
                <img
                  src="/placeholder.svg?height=40&width=40"
                  width={40}
                  height={40}
                  alt="Logo UFPR"
                  className="rounded"
                />
                <div>
                  <h3 className="font-bold">CETO/UFPR</h3>
                  <p className="text-sm text-blue-200">Clínica-Escola de Terapia Ocupacional</p>
                </div>
              </div>
              <p className="text-sm text-blue-200">
                Formação acadêmica e atendimento à comunidade através da integração entre ensino, pesquisa e extensão.
              </p>
            </div>

            <div className="space-y-4">
              <h3 className="font-semibold">Serviços</h3>
              <ul className="space-y-2 text-sm text-blue-200">
                <li>Reabilitação Neurológica</li>
                <li>Desenvolvimento Infantil</li>
                <li>Transtorno do Espectro Autista</li>
                <li>Avaliação e Triagem</li>
              </ul>
            </div>

            <div className="space-y-4">
              <h3 className="font-semibold">Informações</h3>
              <ul className="space-y-2 text-sm text-blue-200">
                <li>Como Funciona</li>
                <li>Fluxo de Atendimento</li>
                <li>Lista de Espera</li>
                <li>Contrato Terapêutico</li>
              </ul>
            </div>

            <div className="space-y-4">
              <h3 className="font-semibold">Contato</h3>
              <ul className="space-y-2 text-sm text-blue-200">
                <li className="flex items-center gap-2">
                  <MapPin className="w-4 h-4" />
                  <span>Campus Jardim Botânico</span>
                </li>
                <li className="flex items-center gap-2">
                  <MessageCircle className="w-4 h-4" />
                  <span>WhatsApp</span>
                </li>
              </ul>
            </div>
          </div>

          <div className="mt-8 pt-8 border-t border-blue-800 text-center text-sm text-blue-200">
            <p>
              © {new Date().getFullYear()} CETO/UFPR - Clínica-Escola de Terapia Ocupacional. Universidade Federal do
              Paraná.
            </p>
          </div>
        </div>
      </footer>
    </div>
  )
}
